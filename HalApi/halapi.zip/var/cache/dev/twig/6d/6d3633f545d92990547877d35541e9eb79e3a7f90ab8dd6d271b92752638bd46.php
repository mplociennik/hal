<?php

/* @Twig/images/icon-minus-square.svg */
class __TwigTemplate_6a1f27b6d65f461d608fe2dc2a40f0833a997b702bf82d37a1ef4d46fa43a9a8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1f1459ca8d5ffaaa5edf597cd996c2ce52bd3021858a55875f92a59c2d98d4b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1f1459ca8d5ffaaa5edf597cd996c2ce52bd3021858a55875f92a59c2d98d4b5->enter($__internal_1f1459ca8d5ffaaa5edf597cd996c2ce52bd3021858a55875f92a59c2d98d4b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        $__internal_f8b245579c8dc117a2c9dec2ae9437d9d449bba6d07612894226e67101d9b04d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8b245579c8dc117a2c9dec2ae9437d9d449bba6d07612894226e67101d9b04d->enter($__internal_f8b245579c8dc117a2c9dec2ae9437d9d449bba6d07612894226e67101d9b04d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
";
        
        $__internal_1f1459ca8d5ffaaa5edf597cd996c2ce52bd3021858a55875f92a59c2d98d4b5->leave($__internal_1f1459ca8d5ffaaa5edf597cd996c2ce52bd3021858a55875f92a59c2d98d4b5_prof);

        
        $__internal_f8b245579c8dc117a2c9dec2ae9437d9d449bba6d07612894226e67101d9b04d->leave($__internal_f8b245579c8dc117a2c9dec2ae9437d9d449bba6d07612894226e67101d9b04d_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
", "@Twig/images/icon-minus-square.svg", "/home/mplociennik/marcin/hal/HalApi/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/icon-minus-square.svg");
    }
}
