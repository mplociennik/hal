<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_cf162f25fa3b6f82cee69ba6f883fb7c82621dcf246f7c18429b115a3511835f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c4c8bca311b3a5cdf29c0775abbc52a03bd9954656c218055b8e31b4754aa307 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c4c8bca311b3a5cdf29c0775abbc52a03bd9954656c218055b8e31b4754aa307->enter($__internal_c4c8bca311b3a5cdf29c0775abbc52a03bd9954656c218055b8e31b4754aa307_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_98f5c317bdac74a42c36c2bfa68ab357bcf294c0682112183aaac3c703b24d7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98f5c317bdac74a42c36c2bfa68ab357bcf294c0682112183aaac3c703b24d7c->enter($__internal_98f5c317bdac74a42c36c2bfa68ab357bcf294c0682112183aaac3c703b24d7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c4c8bca311b3a5cdf29c0775abbc52a03bd9954656c218055b8e31b4754aa307->leave($__internal_c4c8bca311b3a5cdf29c0775abbc52a03bd9954656c218055b8e31b4754aa307_prof);

        
        $__internal_98f5c317bdac74a42c36c2bfa68ab357bcf294c0682112183aaac3c703b24d7c->leave($__internal_98f5c317bdac74a42c36c2bfa68ab357bcf294c0682112183aaac3c703b24d7c_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_afb5d6c46f6999eb84f4841d4e55b65814d1859b145593d9e2897a5d387b9c35 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_afb5d6c46f6999eb84f4841d4e55b65814d1859b145593d9e2897a5d387b9c35->enter($__internal_afb5d6c46f6999eb84f4841d4e55b65814d1859b145593d9e2897a5d387b9c35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_f1d71f0117ff8dbfb4d72febd15aafeb5b5e364f4289e794783147a4ce1152d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1d71f0117ff8dbfb4d72febd15aafeb5b5e364f4289e794783147a4ce1152d4->enter($__internal_f1d71f0117ff8dbfb4d72febd15aafeb5b5e364f4289e794783147a4ce1152d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_f1d71f0117ff8dbfb4d72febd15aafeb5b5e364f4289e794783147a4ce1152d4->leave($__internal_f1d71f0117ff8dbfb4d72febd15aafeb5b5e364f4289e794783147a4ce1152d4_prof);

        
        $__internal_afb5d6c46f6999eb84f4841d4e55b65814d1859b145593d9e2897a5d387b9c35->leave($__internal_afb5d6c46f6999eb84f4841d4e55b65814d1859b145593d9e2897a5d387b9c35_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_5f4b8a4a09e94ac08afa7bbfd8bae4cd646725043acb5083c75a82b67aef51ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f4b8a4a09e94ac08afa7bbfd8bae4cd646725043acb5083c75a82b67aef51ef->enter($__internal_5f4b8a4a09e94ac08afa7bbfd8bae4cd646725043acb5083c75a82b67aef51ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_f1800882b31f1dd1f3a29a0e6383d6a35a6c363b57e03d344597f98d0871a213 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1800882b31f1dd1f3a29a0e6383d6a35a6c363b57e03d344597f98d0871a213->enter($__internal_f1800882b31f1dd1f3a29a0e6383d6a35a6c363b57e03d344597f98d0871a213_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_f1800882b31f1dd1f3a29a0e6383d6a35a6c363b57e03d344597f98d0871a213->leave($__internal_f1800882b31f1dd1f3a29a0e6383d6a35a6c363b57e03d344597f98d0871a213_prof);

        
        $__internal_5f4b8a4a09e94ac08afa7bbfd8bae4cd646725043acb5083c75a82b67aef51ef->leave($__internal_5f4b8a4a09e94ac08afa7bbfd8bae4cd646725043acb5083c75a82b67aef51ef_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c3da7e5ee1bd13278b2548bbf6d1d193adfe6d6f2c3748b915289268f77f6a68 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c3da7e5ee1bd13278b2548bbf6d1d193adfe6d6f2c3748b915289268f77f6a68->enter($__internal_c3da7e5ee1bd13278b2548bbf6d1d193adfe6d6f2c3748b915289268f77f6a68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_06c9d8aef40a56b676d23e72469348769f2ade81d93a0b4479a906ee8fba9ef4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06c9d8aef40a56b676d23e72469348769f2ade81d93a0b4479a906ee8fba9ef4->enter($__internal_06c9d8aef40a56b676d23e72469348769f2ade81d93a0b4479a906ee8fba9ef4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_06c9d8aef40a56b676d23e72469348769f2ade81d93a0b4479a906ee8fba9ef4->leave($__internal_06c9d8aef40a56b676d23e72469348769f2ade81d93a0b4479a906ee8fba9ef4_prof);

        
        $__internal_c3da7e5ee1bd13278b2548bbf6d1d193adfe6d6f2c3748b915289268f77f6a68->leave($__internal_c3da7e5ee1bd13278b2548bbf6d1d193adfe6d6f2c3748b915289268f77f6a68_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/home/mplociennik/marcin/hal/HalApi/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
