<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_3af4a99c1cb655a4825f0a6e01551d674b52d52b622e47d73e3845cb1496152a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c4de6ed63742df1fd22431736f45bafe787b0502965f5eeb12be861cefa479a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c4de6ed63742df1fd22431736f45bafe787b0502965f5eeb12be861cefa479a9->enter($__internal_c4de6ed63742df1fd22431736f45bafe787b0502965f5eeb12be861cefa479a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_04d8e9e90baabe5fa63165f1680bafec979d7b974a4fb3d73d47cc45481bdc8f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04d8e9e90baabe5fa63165f1680bafec979d7b974a4fb3d73d47cc45481bdc8f->enter($__internal_04d8e9e90baabe5fa63165f1680bafec979d7b974a4fb3d73d47cc45481bdc8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c4de6ed63742df1fd22431736f45bafe787b0502965f5eeb12be861cefa479a9->leave($__internal_c4de6ed63742df1fd22431736f45bafe787b0502965f5eeb12be861cefa479a9_prof);

        
        $__internal_04d8e9e90baabe5fa63165f1680bafec979d7b974a4fb3d73d47cc45481bdc8f->leave($__internal_04d8e9e90baabe5fa63165f1680bafec979d7b974a4fb3d73d47cc45481bdc8f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_d1f39fdd2e021e4c24007548182210933ee5bad4c01a32c72c8f660a69f6ccf9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d1f39fdd2e021e4c24007548182210933ee5bad4c01a32c72c8f660a69f6ccf9->enter($__internal_d1f39fdd2e021e4c24007548182210933ee5bad4c01a32c72c8f660a69f6ccf9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_1e1b9e5431ac2ee1f28703d9573da27ae902128377b4fd24d9d7ad1781972cc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e1b9e5431ac2ee1f28703d9573da27ae902128377b4fd24d9d7ad1781972cc5->enter($__internal_1e1b9e5431ac2ee1f28703d9573da27ae902128377b4fd24d9d7ad1781972cc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_1e1b9e5431ac2ee1f28703d9573da27ae902128377b4fd24d9d7ad1781972cc5->leave($__internal_1e1b9e5431ac2ee1f28703d9573da27ae902128377b4fd24d9d7ad1781972cc5_prof);

        
        $__internal_d1f39fdd2e021e4c24007548182210933ee5bad4c01a32c72c8f660a69f6ccf9->leave($__internal_d1f39fdd2e021e4c24007548182210933ee5bad4c01a32c72c8f660a69f6ccf9_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_94eda583507d58f95ab2843a60a2050618ef28c3e0765755da9163f35b5816cf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_94eda583507d58f95ab2843a60a2050618ef28c3e0765755da9163f35b5816cf->enter($__internal_94eda583507d58f95ab2843a60a2050618ef28c3e0765755da9163f35b5816cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_c7b3dc9f3c22cb47f3bd23f8ac6d1a953a69d6f59c082c5f40f3f4739fd4b8ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7b3dc9f3c22cb47f3bd23f8ac6d1a953a69d6f59c082c5f40f3f4739fd4b8ed->enter($__internal_c7b3dc9f3c22cb47f3bd23f8ac6d1a953a69d6f59c082c5f40f3f4739fd4b8ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_c7b3dc9f3c22cb47f3bd23f8ac6d1a953a69d6f59c082c5f40f3f4739fd4b8ed->leave($__internal_c7b3dc9f3c22cb47f3bd23f8ac6d1a953a69d6f59c082c5f40f3f4739fd4b8ed_prof);

        
        $__internal_94eda583507d58f95ab2843a60a2050618ef28c3e0765755da9163f35b5816cf->leave($__internal_94eda583507d58f95ab2843a60a2050618ef28c3e0765755da9163f35b5816cf_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_eb9107b3d6e0c1a13c70730e9486bc2935152b9d151ba090d3b35288ad8990e9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb9107b3d6e0c1a13c70730e9486bc2935152b9d151ba090d3b35288ad8990e9->enter($__internal_eb9107b3d6e0c1a13c70730e9486bc2935152b9d151ba090d3b35288ad8990e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9545167efbda8044f23e77d99047b3e991c5e5e45074cb43a96b112747e7a581 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9545167efbda8044f23e77d99047b3e991c5e5e45074cb43a96b112747e7a581->enter($__internal_9545167efbda8044f23e77d99047b3e991c5e5e45074cb43a96b112747e7a581_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_9545167efbda8044f23e77d99047b3e991c5e5e45074cb43a96b112747e7a581->leave($__internal_9545167efbda8044f23e77d99047b3e991c5e5e45074cb43a96b112747e7a581_prof);

        
        $__internal_eb9107b3d6e0c1a13c70730e9486bc2935152b9d151ba090d3b35288ad8990e9->leave($__internal_eb9107b3d6e0c1a13c70730e9486bc2935152b9d151ba090d3b35288ad8990e9_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/home/mplociennik/marcin/hal/HalApi/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
