<?php

/* base.html.twig */
class __TwigTemplate_e7512925d8fb00307cc049a1006d437f3028b1723b810d6e2acede88a13e1891 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_79b600384f048012a0fcbffb421a57e7371d72143db6f9fb35382329e40bba21 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_79b600384f048012a0fcbffb421a57e7371d72143db6f9fb35382329e40bba21->enter($__internal_79b600384f048012a0fcbffb421a57e7371d72143db6f9fb35382329e40bba21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_2f9aac3a6e16e8fd4a2acdf86633ca9e89428a428a8484800838a3741571857f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f9aac3a6e16e8fd4a2acdf86633ca9e89428a428a8484800838a3741571857f->enter($__internal_2f9aac3a6e16e8fd4a2acdf86633ca9e89428a428a8484800838a3741571857f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_79b600384f048012a0fcbffb421a57e7371d72143db6f9fb35382329e40bba21->leave($__internal_79b600384f048012a0fcbffb421a57e7371d72143db6f9fb35382329e40bba21_prof);

        
        $__internal_2f9aac3a6e16e8fd4a2acdf86633ca9e89428a428a8484800838a3741571857f->leave($__internal_2f9aac3a6e16e8fd4a2acdf86633ca9e89428a428a8484800838a3741571857f_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_a71b9ab42020808cb4a5fd679684b804373c290bfcd5b0732c94f09d88f3069b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a71b9ab42020808cb4a5fd679684b804373c290bfcd5b0732c94f09d88f3069b->enter($__internal_a71b9ab42020808cb4a5fd679684b804373c290bfcd5b0732c94f09d88f3069b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2da3617934ed4d1ebb3b450ae1f6d41e916f7d4f2e1aa9acdfb6522f983757f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2da3617934ed4d1ebb3b450ae1f6d41e916f7d4f2e1aa9acdfb6522f983757f2->enter($__internal_2da3617934ed4d1ebb3b450ae1f6d41e916f7d4f2e1aa9acdfb6522f983757f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_2da3617934ed4d1ebb3b450ae1f6d41e916f7d4f2e1aa9acdfb6522f983757f2->leave($__internal_2da3617934ed4d1ebb3b450ae1f6d41e916f7d4f2e1aa9acdfb6522f983757f2_prof);

        
        $__internal_a71b9ab42020808cb4a5fd679684b804373c290bfcd5b0732c94f09d88f3069b->leave($__internal_a71b9ab42020808cb4a5fd679684b804373c290bfcd5b0732c94f09d88f3069b_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_eeae1ebe96b95e8de7f5d19bc4ec8b634451ba381ffae597790f480de584e446 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eeae1ebe96b95e8de7f5d19bc4ec8b634451ba381ffae597790f480de584e446->enter($__internal_eeae1ebe96b95e8de7f5d19bc4ec8b634451ba381ffae597790f480de584e446_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_0b6e7ac1060376238cd4209bea7ecaf0149ca7806962d372529a1ff1bf5a8fb3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b6e7ac1060376238cd4209bea7ecaf0149ca7806962d372529a1ff1bf5a8fb3->enter($__internal_0b6e7ac1060376238cd4209bea7ecaf0149ca7806962d372529a1ff1bf5a8fb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_0b6e7ac1060376238cd4209bea7ecaf0149ca7806962d372529a1ff1bf5a8fb3->leave($__internal_0b6e7ac1060376238cd4209bea7ecaf0149ca7806962d372529a1ff1bf5a8fb3_prof);

        
        $__internal_eeae1ebe96b95e8de7f5d19bc4ec8b634451ba381ffae597790f480de584e446->leave($__internal_eeae1ebe96b95e8de7f5d19bc4ec8b634451ba381ffae597790f480de584e446_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_778ad0a0c1638ddfbf8c411cede1c1ed984a6b30c3c46be7db1d25c3e2cd628e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_778ad0a0c1638ddfbf8c411cede1c1ed984a6b30c3c46be7db1d25c3e2cd628e->enter($__internal_778ad0a0c1638ddfbf8c411cede1c1ed984a6b30c3c46be7db1d25c3e2cd628e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0cf77a91229f0e3d48e48e6876aba7e7402f17344f166ed4cbb2505f6dac294a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0cf77a91229f0e3d48e48e6876aba7e7402f17344f166ed4cbb2505f6dac294a->enter($__internal_0cf77a91229f0e3d48e48e6876aba7e7402f17344f166ed4cbb2505f6dac294a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0cf77a91229f0e3d48e48e6876aba7e7402f17344f166ed4cbb2505f6dac294a->leave($__internal_0cf77a91229f0e3d48e48e6876aba7e7402f17344f166ed4cbb2505f6dac294a_prof);

        
        $__internal_778ad0a0c1638ddfbf8c411cede1c1ed984a6b30c3c46be7db1d25c3e2cd628e->leave($__internal_778ad0a0c1638ddfbf8c411cede1c1ed984a6b30c3c46be7db1d25c3e2cd628e_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_78887cf9a02c9fae1f03503de34a183aadb39f672029b416e35c9ee94fa07120 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78887cf9a02c9fae1f03503de34a183aadb39f672029b416e35c9ee94fa07120->enter($__internal_78887cf9a02c9fae1f03503de34a183aadb39f672029b416e35c9ee94fa07120_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_f6eb474195b1f08c310cbaf8e75d537dff75fa923cb64f3edce337f728c1281b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6eb474195b1f08c310cbaf8e75d537dff75fa923cb64f3edce337f728c1281b->enter($__internal_f6eb474195b1f08c310cbaf8e75d537dff75fa923cb64f3edce337f728c1281b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_f6eb474195b1f08c310cbaf8e75d537dff75fa923cb64f3edce337f728c1281b->leave($__internal_f6eb474195b1f08c310cbaf8e75d537dff75fa923cb64f3edce337f728c1281b_prof);

        
        $__internal_78887cf9a02c9fae1f03503de34a183aadb39f672029b416e35c9ee94fa07120->leave($__internal_78887cf9a02c9fae1f03503de34a183aadb39f672029b416e35c9ee94fa07120_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/home/mplociennik/marcin/hal/HalApi/app/Resources/views/base.html.twig");
    }
}
